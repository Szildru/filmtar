package classok;

import java.util.ArrayList;

public class Main {
	
	protected static ArrayList<Film> filmlista = new ArrayList<Film>();
	
	public static void main(String[] args) {
		
		
		filmlista = Serialization.fileBe(filmlista);
		Menu.menu();
		
	}

}
