package classok;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Menupont {	
	
	
	public static void list(ArrayList<Film> l) {
		for (int i = 0; i<l.size() ; i++) {
			System.out.println(l.get(i));
		}
	}
		
	public static ArrayList<Film> kereses(ArrayList<Film> l, String s) {
		Iterator<Film> it = l.iterator();
		ArrayList<Film> talalatok = new ArrayList<Film>();
		while(it.hasNext()) {
			Film kovetkezo = it.next();
			if (kovetkezo.getCim().toLowerCase().contains(s.toLowerCase())) {
				talalatok.add(kovetkezo);
			}
		}
		return talalatok;
	}

	public static void hozzaadDont(ArrayList<Film> l, String sor) {
		try {
			String[] s = sor.split("; ");
			s[0] = s[0].toLowerCase();
			if ("sima".contains(s[0])) {
				hozzaadFilm(l,s);
			}else if ("családi".contains(s[0])) {
				hozzaadCsaladi(l,s);
			}else if ("dokumentumfilm".contains(s[0])) {
				hozzaadDokumentum(l,s);
			}else {
				System.out.println("Sikertelen hozzáadás! Rosszul adta meg az adatokat!");
			}
		}catch (Exception e)
		{
			System.out.println("Rosszul adta meg az adatokat!");
		}
		
	}
	
	public static void hozzaadFilm(ArrayList<Film> l, String[] s) {
		l.add(new Film(s[1], Integer.parseInt(s[2]), Integer.parseInt(s[2])));
		System.out.println("Sikeres hozzáadás!");
	}
	
	public static void hozzaadCsaladi(ArrayList<Film> l, String[] s) {
		l.add(new Csaladifilm(s[1], Integer.parseInt(s[2]), Integer.parseInt(s[3]), Integer.parseInt(s[4])));
		System.out.println("Sikeres hozzáadás!");
	}
	
	public static void hozzaadDokumentum(ArrayList<Film> l, String[] s) {
		l.add(new Dokumentumfilm(s[1], Integer.parseInt(s[2]), Integer.parseInt(s[3]), s[4]));
		System.out.println("Sikeres hozzáadás!");
	}
	
	public static void torol(ArrayList<Film> l, String s) {
		
		for (int i = 0; i< l.size(); i++) {
			if (l.get(i).getCim().toLowerCase().contains(s.toLowerCase())) {
				System.out.println(l.get(i).getCim() + " sikeresen törölve!");
				l.remove(i);
				break;
			}
		}
	}
	
	public static boolean multiple(ArrayList<Film> l, String s) {
		int db = 0;
		for (int i = 0; i< l.size(); i++) {
			if (l.get(i).getCim().toLowerCase().equals(s.toLowerCase())) {
				return false;
			}
			if (l.get(i).getCim().toLowerCase().contains(s.toLowerCase())) {
				
				db++;
				if (db == 2) {
					return true;
				}
			}
		}		
		return false;
		
	}
	
}
