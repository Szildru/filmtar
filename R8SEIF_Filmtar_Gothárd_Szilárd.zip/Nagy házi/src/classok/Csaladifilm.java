package classok;

public class Csaladifilm extends Film{
	
	private int korhatar; // film korhatárbesorolása
	
	public Csaladifilm(String c, int m, int h, int k) {
		super(c,m,h);
		korhatar = k;
	}
	
	// getter, setter és toString metódusok
	public int getKorhatar() {return korhatar;}
	public void setKorhatar(int k) {korhatar = k;}
	public String toString() {return super.toString() + "\tKorhatár: " + korhatar;}

}
