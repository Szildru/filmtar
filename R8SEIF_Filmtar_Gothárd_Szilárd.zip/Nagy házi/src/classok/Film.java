package classok;
import java.io.Serializable;

public class Film implements Serializable{
	
	private String cim; // film címe
	private int megjelenes; // film megjelenésének az éve
	private int hossz; // film hossza percekben
	
	public Film(String c, int m, int h) {
		cim = c;
		megjelenes = m;
		hossz = h;
	}
	// getter, setter és toString metódusok
	public String getCim() {return cim;}
	public int getMegjelenes() {return megjelenes;}
	public int getHossz() {return hossz;}
	public void setCim(String c) {cim = c;}
	public void setMegjelenes(int m) {megjelenes = m;}
	public void setHossz(int h) {hossz = h;}
	public String toString() {return cim + "\tMegjelenési év: " + megjelenes + "\tHossz: " + hossz;}

}
