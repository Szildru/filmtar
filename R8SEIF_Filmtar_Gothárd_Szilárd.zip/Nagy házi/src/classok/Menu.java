package classok;

import java.util.Scanner;

public class Menu {
	
	public static void menu() {
		
		// Állapotgép állapotai
		int ALAP = 0;
		int LISTAZAS = 1;
		int KERES = 2;
		int TOROL = 3;
		int HOZZAAD = 4;
		int MENTES = 5;
		int KILEP = 6;
		
		int allapot = ALAP;
		
		Scanner input = new Scanner(System.in);
		
		while (true) {			
			
			if (allapot == ALAP) {
				System.out.println("1. Filmek listázása");
				System.out.println("2. Film keresése");
				System.out.println("3. Film törlése");
				System.out.println("4. Film hozzáadása");
				System.out.println("5. Mentés");
				System.out.println("6. Kilépés");
				System.out.println("Választott menüpont száma: ");
				
				String x = input.nextLine();		
				try {					
					while(Integer.parseInt(x) < 0 || Integer.parseInt(x) > 6) {
						System.out.println("Rossz szám.");
						x = input.nextLine();
					}
					allapot = Integer.parseInt(x);
				}catch (Exception e) {
					System.out.println("Kérem a menüpont számát irja be, majd nyomjon entert.");
				}
			}
			if (allapot == LISTAZAS) {
				Menupont.list(Main.filmlista);
				allapot = vissza();			
			}
			if (allapot == KERES) {
				System.out.println("Kérem adja meg a film címét: "); 
				String cim = input.nextLine();
				if(Menupont.kereses(Main.filmlista,cim).isEmpty()) {
					System.out.println("Nincs találtat '" + cim + "' kifejezésre.");
				}
				Menupont.list(Menupont.kereses(Main.filmlista,cim));
				allapot = vissza();
			}
			if (allapot == TOROL) {
				System.out.println("Adja meg a film címét amit ki szeretne törölni: ");
				String cim = input.nextLine();
				while (Menupont.multiple(Main.filmlista,cim)) {
					System.out.println("A '" + cim + "' kifejezésre az alábbi találatok vannak: ");
					Menupont.list(Menupont.kereses(Main.filmlista,cim));
					System.out.println("Kérem adja meg a film pontosabb cimét: ");
					cim = input.nextLine();
				}
				Menupont.torol(Main.filmlista,cim);
				allapot = vissza();
			}
			if (allapot == HOZZAAD) {
				System.out.println("Kérem az alábbi módon adja meg az adatokat: ");
				System.out.println("Tipus 3 féle lehet: sima, családi, dokumentum.");
				System.out.println("Leirás csak dokumentum film esetén kell.");
				System.out.println("Korhatár csak családi film esetén kell.");
				System.out.println("Tipus; Cim; Megjelenés; Hossz(percben); (Leirás/Korhatár)");
				String s = input.nextLine();
				Menupont.hozzaadDont(Main.filmlista, s);
				allapot = vissza();
			}
			if (allapot == MENTES) {
				Serialization.fileKi(Main.filmlista);
				allapot = vissza();
			}
			if (allapot == KILEP) {
				Serialization.fileKi(Main.filmlista);
				exit();
			}
		}
	}
	
	public static int vissza() {
		System.out.println();
		System.out.println("A visszalépéshez nyomja meg a '0' gombot és nyomja meg az entert."); 
		Scanner input = new Scanner(System.in); 
		while(true) {
			String back = input.nextLine();
			if (back.equals("0")) {
				return 0;
			}
		}
	}
	
	public static void exit() {
		System.out.println("Viszont látásra!");
		System.exit(0);
	}
	

}
