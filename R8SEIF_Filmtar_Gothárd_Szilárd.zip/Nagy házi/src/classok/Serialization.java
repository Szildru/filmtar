package classok;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.io.IOException;

public class Serialization {
	
	public static ArrayList<Film> fileBe(ArrayList<Film> l) {
		try {
			FileInputStream f = new FileInputStream("filmek");
			ObjectInputStream in = new ObjectInputStream(f);
			l = (ArrayList<Film>)in.readObject();
			f.close();
			in.close();
			System.out.println("Sikeres betöltés!");
		}catch (IOException e) {
			System.out.println("Sikertelen betöltés.");
			e.getMessage();
		}catch (ClassNotFoundException e) {
			e.getMessage();
		}
		return l;
	
	}
	
	public static void fileKi(ArrayList<Film> l) {
		try {
			FileOutputStream f = new FileOutputStream("filmek", false);
			ObjectOutputStream out = new ObjectOutputStream(f);
			out.writeObject(l);
			f.close();
			out.close();
			System.out.println("Sikeres mentés!");
		}catch (IOException e) {
			System.out.println("Sikertelen mentés.");
		}
		
	}

}
