package classok;

public class Dokumentumfilm extends Film{
	
	private String leiras; //egy rövid leírás a filmről
	
	public Dokumentumfilm(String c, int m, int h, String l) {
		super(c,m,h);
		leiras = l;
	}
	
	// getter, setter és toString metódusok
	public String getLeiras() {return leiras;}
	public void setLeiras(String l) { leiras = l;}
	public String toString() {return super.toString() + "\tLeirás: " + leiras;} 
	
}
