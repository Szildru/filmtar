package classok;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

public class TestFilm {

	Film f, f2;
	Dokumentumfilm d;
	Csaladifilm cs;
	ArrayList<Film> al, al2;
	String s;
	boolean van;
	
	@Before
	public void setUp() {
		f = new Film("Sonic", 1887, 76);
		d = new Dokumentumfilm("Élet a Földön", 2020, 123, "Ez egy nagyon jó dokumentumfilm");
		cs = new Csaladifilm("Halálos Iramban", 2021, 900, 5);
		
	}
	
	@Test
	public void testGet() {
		assertEquals("Sonic", f.getCim());
		assertEquals(1887, f.getMegjelenes());
		assertEquals(76, f.getHossz());
		assertEquals("Élet a Földön",d.getCim());
		assertEquals(2020,d.getMegjelenes());
		assertEquals(123,d.getHossz());
		assertEquals("Ez egy nagyon jó dokumentumfilm",d.getLeiras());
		assertEquals("Halálos Iramban", cs.getCim());
		assertEquals(2021, cs.getMegjelenes());
		assertEquals(900, cs.getHossz());
		assertEquals(5, cs.getKorhatar());
		f.setCim("film");
		assertEquals(f.getCim(),"film");
		f.setMegjelenes(1988);
		assertEquals(f.getMegjelenes(),1988);
		f.setHossz(99);
		assertEquals(f.getHossz(),99);
		cs.setKorhatar(16);
		assertEquals(cs.getKorhatar(),16);
		d.setLeiras("Van neki");
		assertEquals(d.getLeiras(),"Van neki");
	}
	
	@Test
	public void testKereses(){
		s = "Sonic";
		al = new ArrayList<Film>();
		al.add(cs);
		al.add(f);
		al.add(d);
		System.out.println(Menupont.kereses(al,s).size());
		assertEquals(1,Menupont.kereses(al,s).size());
	}
	
	@Test
	public void testList() {
		al = new ArrayList<Film>();
		al.add(cs);
		al.add(f);
		al.add(d);
		Menupont.list(al);
		assertEquals(3,al.size());
	}
	
	@Test
	public void testTorol() {
		al = new ArrayList<Film>();
		al.add(cs);
		al.add(f);
		al.add(d);
		Menupont.torol(al,f.getCim());
		if(al.contains("Sonic")) {
			van = true;
		}else {
			van = false;
		}
		assertEquals(false,van);
	}

	@Test
	public void testFile() {
		al = new ArrayList<Film>();
		al2 = new ArrayList<Film>();
		al.add(cs);
		al.add(f);
		al.add(d);
		Serialization.fileKi(al);
		al2 = Serialization.fileBe(al2);
		System.out.print(al2);
		van = false;
		for(int i = 0; i < al.size(); i++) {
			if(al.get(i).toString().equals(al2.get(i).toString())) {
				van = true;
			}
		}
		assertEquals(true,van);
		
	}

	@Test
	public void testMultiple() {
		s = "So";
		al = new ArrayList<Film>();
		al.add(cs);
		f2 = new Film("Sonic 2", 2002, 78);
		al.add(f2);
		al.add(d);
		assertEquals(Menupont.multiple(al,s),false);
		al.add(f);
		assertEquals(Menupont.multiple(al,s),true);
	}

	@Test
	public void testAdd() {
		al = new ArrayList<Film>();
		s = "sima; Bosszúállók; 2006; 120";
		Menupont.hozzaadDont(al, s);
		assertEquals(al.get(0).getCim(), "Bosszúállók");
		s = "családi; Die Hard; 2006; 120; 16";
		Menupont.hozzaadDont(al, s);
		assertEquals(al.get(1).getCim(), "Die Hard");
		s = "dokumentum; Élet; 2000; 120; Ez egy doksifilm";
		Menupont.hozzaadDont(al, s);
		assertEquals(al.get(2).getCim(), "Élet");
	}
}
